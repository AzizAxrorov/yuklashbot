
from telegram import Bot, Update
from telegram.ext import CommandHandler, MessageHandler, Filters, Updater
import requests
import re

TOKEN = '7796031226:AAFit0CqVKOisiNpuOQDqNOsluL1V5lYUYs'

# Instagramdan video yuklab olish uchun oddiy scraper

def get_instagram_video(insta_url):
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
        }
        response = requests.get(insta_url, headers=headers)
        if response.status_code == 200:
            matches = re.findall(r'\"video_url\":\"(.*?)\"', response.text)
            if matches:
                video_url = matches[0].replace("\\u0026", "&").replace("\/", "/")
                return video_url
    except Exception as e:
        print(f"Xatolik: {e}")
    return None


def start(update, context):
    update.message.reply_text("Instagram videoning linkini yuboring!")


def handle_message(update, context):
    link = update.message.text.strip()
    if not link.startswith("http"):
        update.message.reply_text("Iltimos, to'g'ri Instagram link yuboring.")
        return

    video_url = get_instagram_video(link)
    if video_url:
        try:
            context.bot.send_video(chat_id=update.effective_chat.id, video=video_url)
        except Exception as e:
            print(f"Yuborishda xato: {e}")
            update.message.reply_text("Videoni yuborib bo‘lmadi.")
    else:
        update.message.reply_text("Videoni yuklab bo‘lmadi. Iltimos, tekshirib qayta yuboring.")


def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))

    updater.start_polling()
    updater.idle()


if __name__ == '__main__':
    main()
